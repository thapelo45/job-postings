import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  FileText, 
  Clock, 
  CheckCircle, 
  XCircle, 
  Eye, 
  Download, 
  Filter,
  Search,
  Calendar,
  Briefcase,
  User,
  Mail,
  Phone
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import { useNotifications } from '../contexts/NotificationContext';

interface Application {
  id: number;
  jobTitle: string;
  company: string;
  applicantName?: string;
  applicantEmail?: string;
  applicantPhone?: string;
  status: 'pending' | 'reviewing' | 'interview' | 'accepted' | 'rejected';
  appliedDate: string;
  lastUpdate: string;
  coverLetter?: string;
  resume?: string;
  notes?: string;
}

const Applications: React.FC = () => {
  const { user } = useAuth();
  const { t } = useLanguage();
  const { addNotification } = useNotifications();
  const [applications, setApplications] = useState<Application[]>([]);
  const [filteredApplications, setFilteredApplications] = useState<Application[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [selectedApplication, setSelectedApplication] = useState<Application | null>(null);
  const [showDetails, setShowDetails] = useState(false);

  // Mock data
  const mockJobSeekerApplications: Application[] = [
    {
      id: 1,
      jobTitle: 'Software Developer',
      company: 'TechCorp Lesotho',
      status: 'interview',
      appliedDate: '2025-01-10',
      lastUpdate: '2025-01-12',
      notes: 'Interview scheduled for next week'
    },
    {
      id: 2,
      jobTitle: 'Marketing Manager',
      company: 'Digital Solutions',
      status: 'pending',
      appliedDate: '2025-01-08',
      lastUpdate: '2025-01-08'
    },
    {
      id: 3,
      jobTitle: 'Accountant',
      company: 'Finance Pro',
      status: 'rejected',
      appliedDate: '2025-01-05',
      lastUpdate: '2025-01-11',
      notes: 'Position filled by another candidate'
    },
    {
      id: 4,
      jobTitle: 'Project Manager',
      company: 'Construction Plus',
      status: 'reviewing',
      appliedDate: '2025-01-12',
      lastUpdate: '2025-01-13'
    }
  ];

  const mockEmployerApplications: Application[] = [
    {
      id: 1,
      jobTitle: 'Senior Developer',
      applicantName: 'John Doe',
      applicantEmail: 'john.doe@email.com',
      applicantPhone: '+266 5555 0001',
      status: 'pending',
      appliedDate: '2025-01-13',
      lastUpdate: '2025-01-13',
      coverLetter: 'I am excited to apply for the Senior Developer position...',
      resume: 'john_doe_resume.pdf'
    },
    {
      id: 2,
      jobTitle: 'Senior Developer',
      applicantName: 'Jane Smith',
      applicantEmail: 'jane.smith@email.com',
      applicantPhone: '+266 5555 0002',
      status: 'interview',
      appliedDate: '2025-01-12',
      lastUpdate: '2025-01-13',
      coverLetter: 'With 5 years of experience in React and Node.js...',
      resume: 'jane_smith_resume.pdf'
    },
    {
      id: 3,
      jobTitle: 'Project Manager',
      applicantName: 'Mike Johnson',
      applicantEmail: 'mike.johnson@email.com',
      applicantPhone: '+266 5555 0003',
      status: 'reviewing',
      appliedDate: '2025-01-11',
      lastUpdate: '2025-01-12',
      coverLetter: 'I have successfully managed multiple construction projects...',
      resume: 'mike_johnson_resume.pdf'
    },
    {
      id: 4,
      jobTitle: 'UI Designer',
      applicantName: 'Sarah Wilson',
      applicantEmail: 'sarah.wilson@email.com',
      applicantPhone: '+266 5555 0004',
      status: 'accepted',
      appliedDate: '2025-01-09',
      lastUpdate: '2025-01-11',
      coverLetter: 'My portfolio demonstrates my expertise in modern UI design...',
      resume: 'sarah_wilson_resume.pdf'
    }
  ];

  useEffect(() => {
    // Load applications based on user role
    const apps = user?.role === 'jobseeker' ? mockJobSeekerApplications : mockEmployerApplications;
    setApplications(apps);
    setFilteredApplications(apps);
  }, [user]);

  useEffect(() => {
    // Filter applications
    let filtered = applications;

    if (searchQuery) {
      filtered = filtered.filter(app =>
        app.jobTitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (app.company && app.company.toLowerCase().includes(searchQuery.toLowerCase())) ||
        (app.applicantName && app.applicantName.toLowerCase().includes(searchQuery.toLowerCase()))
      );
    }

    if (statusFilter) {
      filtered = filtered.filter(app => app.status === statusFilter);
    }

    setFilteredApplications(filtered);
  }, [searchQuery, statusFilter, applications]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'text-yellow-600 bg-yellow-100';
      case 'reviewing': return 'text-blue-600 bg-blue-100';
      case 'interview': return 'text-purple-600 bg-purple-100';
      case 'accepted': return 'text-green-600 bg-green-100';
      case 'rejected': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending': return <Clock className="h-4 w-4" />;
      case 'reviewing': return <Eye className="h-4 w-4" />;
      case 'interview': return <Calendar className="h-4 w-4" />;
      case 'accepted': return <CheckCircle className="h-4 w-4" />;
      case 'rejected': return <XCircle className="h-4 w-4" />;
      default: return <Clock className="h-4 w-4" />;
    }
  };

  const handleStatusUpdate = (applicationId: number, newStatus: string) => {
    setApplications(prev =>
      prev.map(app =>
        app.id === applicationId
          ? { ...app, status: newStatus as any, lastUpdate: new Date().toISOString().split('T')[0] }
          : app
      )
    );

    // Add notification for job seeker when status changes
    const application = applications.find(app => app.id === applicationId);
    if (application && user?.role === 'employer') {
      let notificationMessage = '';
      switch (newStatus) {
        case 'interview':
          notificationMessage = `Interview scheduled for ${application.jobTitle} position.`;
          break;
        case 'accepted':
          notificationMessage = `Congratulations! Your application for ${application.jobTitle} has been accepted.`;
          break;
        case 'rejected':
          notificationMessage = `Your application for ${application.jobTitle} has been reviewed.`;
          break;
        default:
          notificationMessage = `Your application status for ${application.jobTitle} has been updated.`;
      }

      addNotification({
        type: newStatus === 'interview' ? 'interview_scheduled' : 'application_status',
        title: 'Application Status Updated',
        message: notificationMessage,
        actionData: {
          applicationId: applicationId.toString(),
          userId: user.id,
          userType: 'employer',
          userName: user.name,
          userEmail: user.email,
          userPhone: user.profile?.phone,
          jobTitle: application.jobTitle,
          companyName: user.profile?.company
        }
      });
    }
  };

  const handleViewDetails = (application: Application) => {
    setSelectedApplication(application);
    setShowDetails(true);
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            {user?.role === 'jobseeker' ? 'My Applications' : 'Job Applications'}
          </h1>
          <p className="text-gray-600">
            {user?.role === 'jobseeker' 
              ? 'Track the status of your job applications'
              : 'Review and manage applications for your job postings'
            }
          </p>
        </div>

        {/* Search and Filters */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <div className="flex flex-col lg:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="h-5 w-5 text-gray-400 absolute left-3 top-3" />
                <input
                  type="text"
                  placeholder={user?.role === 'jobseeker' ? 'Search jobs or companies...' : 'Search applicants or positions...'}
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="">All Status</option>
                <option value="pending">Pending</option>
                <option value="reviewing">Reviewing</option>
                <option value="interview">Interview</option>
                <option value="accepted">Accepted</option>
                <option value="rejected">Rejected</option>
              </select>
            </div>
          </div>
        </div>

        {/* Applications List */}
        <div className="space-y-4">
          {filteredApplications.map((application) => (
            <div key={application.id} className="bg-white rounded-lg shadow-md p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex-1">
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">
                    {application.jobTitle}
                  </h3>
                  {user?.role === 'jobseeker' ? (
                    <p className="text-gray-600 font-medium">{application.company}</p>
                  ) : (
                    <div className="space-y-1">
                      <p className="text-gray-900 font-medium">{application.applicantName}</p>
                      <p className="text-gray-600 text-sm">{application.applicantEmail}</p>
                    </div>
                  )}
                </div>
                <div className="text-right">
                  <span className={`inline-flex items-center space-x-1 px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(application.status)}`}>
                    {getStatusIcon(application.status)}
                    <span className="capitalize">{application.status}</span>
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                <div className="flex items-center text-gray-600">
                  <Calendar className="h-4 w-4 mr-2" />
                  <span className="text-sm">Applied: {new Date(application.appliedDate).toLocaleDateString()}</span>
                </div>
                <div className="flex items-center text-gray-600">
                  <Clock className="h-4 w-4 mr-2" />
                  <span className="text-sm">Updated: {new Date(application.lastUpdate).toLocaleDateString()}</span>
                </div>
                {user?.role === 'employer' && application.applicantPhone && (
                  <div className="flex items-center text-gray-600">
                    <Phone className="h-4 w-4 mr-2" />
                    <span className="text-sm">{application.applicantPhone}</span>
                  </div>
                )}
              </div>

              {application.notes && (
                <div className="mb-4 p-3 bg-gray-50 rounded-lg">
                  <p className="text-sm text-gray-700">{application.notes}</p>
                </div>
              )}

              <div className="flex items-center justify-between">
                <div className="flex space-x-3">
                  <button
                    onClick={() => handleViewDetails(application)}
                    className="flex items-center space-x-2 px-4 py-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                  >
                    <Eye className="h-4 w-4" />
                    <span>View Details</span>
                  </button>
                  {user?.role === 'employer' && application.resume && (
                    <button className="flex items-center space-x-2 px-4 py-2 text-green-600 hover:bg-green-50 rounded-lg transition-colors">
                      <Download className="h-4 w-4" />
                      <span>Download Resume</span>
                    </button>
                  )}
                </div>

                {user?.role === 'employer' && application.status === 'pending' && (
                  <div className="flex space-x-2">
                    <button
                      onClick={() => handleStatusUpdate(application.id, 'interview')}
                      className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm"
                    >
                      Schedule Interview
                    </button>
                    <button
                      onClick={() => handleStatusUpdate(application.id, 'rejected')}
                      className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors text-sm"
                    >
                      Reject
                    </button>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>

        {filteredApplications.length === 0 && (
          <div className="text-center py-12">
            <div className="text-gray-400 mb-4">
              <FileText className="h-16 w-16 mx-auto" />
            </div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">No applications found</h3>
            <p className="text-gray-600 mb-4">
              {user?.role === 'jobseeker' 
                ? "You haven't applied to any jobs yet."
                : "No applications have been received yet."
              }
            </p>
            {user?.role === 'jobseeker' && (
              <Link
                to="/jobs"
                className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                <Briefcase className="h-4 w-4 mr-2" />
                Browse Jobs
              </Link>
            )}
          </div>
        )}

        {/* Application Details Modal */}
        {showDetails && selectedApplication && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
              <div className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-2xl font-bold text-gray-900">Application Details</h2>
                  <button
                    onClick={() => setShowDetails(false)}
                    className="text-gray-400 hover:text-gray-600"
                  >
                    <XCircle className="h-6 w-6" />
                  </button>
                </div>

                <div className="space-y-6">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">{selectedApplication.jobTitle}</h3>
                    {user?.role === 'jobseeker' ? (
                      <p className="text-gray-600">{selectedApplication.company}</p>
                    ) : (
                      <div className="space-y-2">
                        <div className="flex items-center space-x-2">
                          <User className="h-4 w-4 text-gray-400" />
                          <span>{selectedApplication.applicantName}</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Mail className="h-4 w-4 text-gray-400" />
                          <span>{selectedApplication.applicantEmail}</span>
                        </div>
                        {selectedApplication.applicantPhone && (
                          <div className="flex items-center space-x-2">
                            <Phone className="h-4 w-4 text-gray-400" />
                            <span>{selectedApplication.applicantPhone}</span>
                          </div>
                        )}
                      </div>
                    )}
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
                      <span className={`inline-flex items-center space-x-1 px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(selectedApplication.status)}`}>
                        {getStatusIcon(selectedApplication.status)}
                        <span className="capitalize">{selectedApplication.status}</span>
                      </span>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Applied Date</label>
                      <p className="text-gray-900">{new Date(selectedApplication.appliedDate).toLocaleDateString()}</p>
                    </div>
                  </div>

                  {selectedApplication.coverLetter && (
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Cover Letter</label>
                      <div className="p-4 bg-gray-50 rounded-lg">
                        <p className="text-gray-900 whitespace-pre-wrap">{selectedApplication.coverLetter}</p>
                      </div>
                    </div>
                  )}

                  {selectedApplication.notes && (
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Notes</label>
                      <div className="p-4 bg-gray-50 rounded-lg">
                        <p className="text-gray-900">{selectedApplication.notes}</p>
                      </div>
                    </div>
                  )}

                  {user?.role === 'employer' && (
                    <div className="flex space-x-3 pt-4 border-t">
                      <button
                        onClick={() => {
                          handleStatusUpdate(selectedApplication.id, 'interview');
                          setShowDetails(false);
                        }}
                        className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                      >
                        Schedule Interview
                      </button>
                      <button
                        onClick={() => {
                          handleStatusUpdate(selectedApplication.id, 'accepted');
                          setShowDetails(false);
                        }}
                        className="flex-1 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
                      >
                        Accept
                      </button>
                      <button
                        onClick={() => {
                          handleStatusUpdate(selectedApplication.id, 'rejected');
                          setShowDetails(false);
                        }}
                        className="flex-1 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
                      >
                        Reject
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Applications;