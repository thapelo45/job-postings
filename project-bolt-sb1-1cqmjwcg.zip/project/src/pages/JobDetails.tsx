import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { MapPin, Briefcase, Clock, DollarSign, Users, Building, ArrowLeft, Heart, Share2 } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import { useNotifications } from '../contexts/NotificationContext';

interface Job {
  id: number;
  title: string;
  company: string;
  location: string;
  type: string;
  category: string;
  salary: string;
  posted: string;
  description: string;
  requirements: string[];
  responsibilities: string[];
  skills: string[];
  experience: string;
  benefits: string[];
  companyInfo: {
    size: string;
    industry: string;
    website: string;
    description: string;
  };
}

const JobDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();
  const { t } = useLanguage();
  const { addNotification } = useNotifications();
  const navigate = useNavigate();
  const [job, setJob] = useState<Job | null>(null);
  const [loading, setLoading] = useState(true);
  const [applied, setApplied] = useState(false);
  const [saved, setSaved] = useState(false);

  // Mock job data - in real app, this would come from API
  const mockJob: Job = {
    id: parseInt(id || '1'),
    title: 'Software Developer',
    company: 'TechCorp Lesotho',
    location: 'Maseru',
    type: 'Full-time',
    category: 'Technology',
    salary: 'M 15,000 - M 25,000',
    posted: '2 days ago',
    description: `We are seeking a talented Software Developer to join our growing technology team in Maseru. This is an excellent opportunity for a motivated individual to work on cutting-edge projects and contribute to the digital transformation of Lesotho.

The successful candidate will be responsible for developing and maintaining web applications, collaborating with cross-functional teams, and ensuring high-quality code delivery. You will work in an agile environment with modern technologies and have opportunities for professional growth.`,
    requirements: [
      'Bachelor\'s degree in Computer Science or related field',
      '2+ years of experience in software development',
      'Proficiency in React, Node.js, and TypeScript',
      'Experience with database systems (MySQL, MongoDB)',
      'Strong problem-solving and analytical skills',
      'Excellent communication skills in English',
      'Knowledge of Sesotho is a plus'
    ],
    responsibilities: [
      'Develop and maintain web applications using modern frameworks',
      'Collaborate with designers and product managers',
      'Write clean, maintainable, and well-documented code',
      'Participate in code reviews and technical discussions',
      'Troubleshoot and debug applications',
      'Stay updated with latest technology trends',
      'Mentor junior developers'
    ],
    skills: ['React', 'Node.js', 'TypeScript', 'MongoDB', 'Git', 'Agile'],
    experience: 'Mid-level',
    benefits: [
      'Competitive salary package',
      'Health insurance coverage',
      'Professional development opportunities',
      'Flexible working hours',
      'Annual leave and sick leave',
      'Performance bonuses',
      'Modern office environment'
    ],
    companyInfo: {
      size: '50-100 employees',
      industry: 'Information Technology',
      website: 'www.techcorp.co.ls',
      description: 'TechCorp Lesotho is a leading technology company focused on delivering innovative software solutions for businesses across Southern Africa. We pride ourselves on fostering a collaborative work environment and investing in our employees\' growth.'
    }
  };

  useEffect(() => {
    // Simulate API call
    setTimeout(() => {
      setJob(mockJob);
      setLoading(false);
    }, 500);
  }, [id]);

  const handleApply = () => {
    if (!user) {
      navigate('/login');
      return;
    }
    setApplied(true);
    
    // Add notification for employer
    addNotification({
      type: 'new_application',
      title: 'New Application Received',
      message: `${user.name} applied for ${job?.title} position.`,
      actionData: {
        applicationId: Date.now().toString(),
        userId: user.id,
        userType: 'jobseeker',
        userName: user.name,
        userEmail: user.email,
        userPhone: user.profile?.phone,
        jobTitle: job?.title
      }
    });
  };

  const handleSave = () => {
    setSaved(!saved);
    // In real app, this would save/unsave job to user's saved jobs
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: job?.title,
        text: `Check out this job opportunity: ${job?.title} at ${job?.company}`,
        url: window.location.href,
      });
    } else {
      // Fallback: copy to clipboard
      navigator.clipboard.writeText(window.location.href);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!job) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Job Not Found</h2>
          <p className="text-gray-600 mb-6">The job you're looking for doesn't exist or has been removed.</p>
          <button
            onClick={() => navigate('/jobs')}
            className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            Browse All Jobs
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Back Button */}
        <button
          onClick={() => navigate(-1)}
          className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 mb-6 transition-colors"
        >
          <ArrowLeft className="h-5 w-5" />
          <span>Back to Jobs</span>
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Job Header */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="flex justify-between items-start mb-4">
                <div className="flex-1">
                  <h1 className="text-3xl font-bold text-gray-900 mb-2">{job.title}</h1>
                  <p className="text-xl text-gray-600 font-medium mb-4">{job.company}</p>
                  <div className="text-2xl font-bold text-green-600 mb-4">{job.salary}</div>
                </div>
                <div className="flex space-x-2">
                  <button
                    onClick={handleSave}
                    className={`p-2 rounded-lg border transition-colors ${
                      saved 
                        ? 'bg-red-50 border-red-200 text-red-600' 
                        : 'bg-gray-50 border-gray-200 text-gray-600 hover:bg-gray-100'
                    }`}
                  >
                    <Heart className={`h-5 w-5 ${saved ? 'fill-current' : ''}`} />
                  </button>
                  <button
                    onClick={handleShare}
                    className="p-2 rounded-lg border border-gray-200 text-gray-600 hover:bg-gray-100 transition-colors"
                  >
                    <Share2 className="h-5 w-5" />
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                <div className="flex items-center text-gray-600">
                  <MapPin className="h-4 w-4 mr-2" />
                  <span className="text-sm">{job.location}</span>
                </div>
                <div className="flex items-center text-gray-600">
                  <Briefcase className="h-4 w-4 mr-2" />
                  <span className="text-sm">{job.type}</span>
                </div>
                <div className="flex items-center text-gray-600">
                  <DollarSign className="h-4 w-4 mr-2" />
                  <span className="text-sm">{job.experience}</span>
                </div>
                <div className="flex items-center text-gray-600">
                  <Clock className="h-4 w-4 mr-2" />
                  <span className="text-sm">{job.posted}</span>
                </div>
              </div>

              <div className="flex flex-wrap gap-2">
                {job.skills.map((skill) => (
                  <span 
                    key={skill}
                    className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </div>

            {/* Job Description */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-xl font-bold text-gray-900 mb-4">Job Description</h2>
              <div className="prose prose-gray max-w-none">
                {job.description.split('\n\n').map((paragraph, index) => (
                  <p key={index} className="text-gray-600 mb-4">{paragraph}</p>
                ))}
              </div>
            </div>

            {/* Responsibilities */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-xl font-bold text-gray-900 mb-4">Key Responsibilities</h2>
              <ul className="space-y-2">
                {job.responsibilities.map((responsibility, index) => (
                  <li key={index} className="flex items-start">
                    <span className="w-2 h-2 bg-blue-600 rounded-full mt-2 mr-3 flex-shrink-0"></span>
                    <span className="text-gray-600">{responsibility}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Requirements */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-xl font-bold text-gray-900 mb-4">Requirements</h2>
              <ul className="space-y-2">
                {job.requirements.map((requirement, index) => (
                  <li key={index} className="flex items-start">
                    <span className="w-2 h-2 bg-green-600 rounded-full mt-2 mr-3 flex-shrink-0"></span>
                    <span className="text-gray-600">{requirement}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Benefits */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-xl font-bold text-gray-900 mb-4">Benefits & Perks</h2>
              <ul className="space-y-2">
                {job.benefits.map((benefit, index) => (
                  <li key={index} className="flex items-start">
                    <span className="w-2 h-2 bg-orange-600 rounded-full mt-2 mr-3 flex-shrink-0"></span>
                    <span className="text-gray-600">{benefit}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Apply Button */}
            <div className="bg-white rounded-lg shadow-md p-6">
              {applied ? (
                <div className="text-center">
                  <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <span className="text-2xl">✓</span>
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">Application Submitted!</h3>
                  <p className="text-gray-600 text-sm mb-4">
                    Your application has been sent to the employer. You'll receive updates via email.
                  </p>
                  <button
                    onClick={() => navigate('/dashboard')}
                    className="w-full px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                  >
                    View Applications
                  </button>
                </div>
              ) : (
                <div>
                  <button
                    onClick={handleApply}
                    className="w-full px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-semibold mb-4"
                  >
                    {user ? 'Apply Now' : 'Login to Apply'}
                  </button>
                  <p className="text-gray-600 text-sm text-center">
                    By applying, you agree to our terms and conditions.
                  </p>
                </div>
              )}
            </div>

            {/* Company Info */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">About {job.company}</h3>
              <div className="space-y-3 mb-4">
                <div className="flex items-center text-gray-600">
                  <Building className="h-4 w-4 mr-2" />
                  <span className="text-sm">{job.companyInfo.industry}</span>
                </div>
                <div className="flex items-center text-gray-600">
                  <Users className="h-4 w-4 mr-2" />
                  <span className="text-sm">{job.companyInfo.size}</span>
                </div>
              </div>
              <p className="text-gray-600 text-sm mb-4">{job.companyInfo.description}</p>
              <a
                href={`https://${job.companyInfo.website}`}
                target="_blank"
                rel="noopener noreferrer"
                className="text-blue-600 hover:text-blue-700 text-sm font-medium"
              >
                Visit Company Website →
              </a>
            </div>

            {/* Similar Jobs */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Similar Jobs</h3>
              <div className="space-y-3">
                {[
                  { title: 'Frontend Developer', company: 'Digital Solutions', location: 'Maseru' },
                  { title: 'Full Stack Developer', company: 'Innovation Hub', location: 'Hlotse' },
                  { title: 'Mobile App Developer', company: 'Mobile First', location: 'Maseru' }
                ].map((similarJob, index) => (
                  <div key={index} className="border-b border-gray-100 pb-3 last:border-b-0">
                    <h4 className="font-medium text-gray-900 text-sm">{similarJob.title}</h4>
                    <p className="text-gray-600 text-xs">{similarJob.company}</p>
                    <p className="text-gray-500 text-xs">{similarJob.location}</p>
                  </div>
                ))}
              </div>
              <button
                onClick={() => navigate('/jobs')}
                className="w-full mt-4 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors text-sm"
              >
                View More Jobs
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default JobDetails;