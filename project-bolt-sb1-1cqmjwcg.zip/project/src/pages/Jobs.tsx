import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Search, MapPin, Briefcase, Clock, DollarSign, Filter, ChevronDown } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

interface Job {
  id: number;
  title: string;
  company: string;
  location: string;
  type: string;
  category: string;
  salary: string;
  posted: string;
  description: string;
  skills: string[];
  experience: string;
}

const Jobs: React.FC = () => {
  const { t } = useLanguage();
  const location = useLocation();
  const [jobs, setJobs] = useState<Job[]>([]);
  const [filteredJobs, setFilteredJobs] = useState<Job[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [filters, setFilters] = useState({
    location: '',
    category: '',
    type: '',
    experience: '',
    salaryRange: ''
  });
  const [showFilters, setShowFilters] = useState(false);

  // Mock job data
  const mockJobs: Job[] = [
    {
      id: 1,
      title: 'Software Developer',
      company: 'TechCorp Lesotho',
      location: 'Maseru',
      type: 'Full-time',
      category: 'Technology',
      salary: 'M 15,000 - M 25,000',
      posted: '2 days ago',
      description: 'We are looking for a skilled Software Developer to join our growing team...',
      skills: ['React', 'Node.js', 'TypeScript', 'MongoDB'],
      experience: 'Mid-level'
    },
    {
      id: 2,
      title: 'Marketing Manager',
      company: 'Digital Solutions Ltd',
      location: 'Maseru',
      type: 'Full-time',
      category: 'Marketing',
      salary: 'M 12,000 - M 18,000',
      posted: '1 day ago',
      description: 'Join our dynamic marketing team and help grow our brand presence...',
      skills: ['Digital Marketing', 'SEO', 'Analytics', 'Content Strategy'],
      experience: 'Senior'
    },
    {
      id: 3,
      title: 'Accountant',
      company: 'Finance Pro Services',
      location: 'Hlotse',
      type: 'Full-time',
      category: 'Finance',
      salary: 'M 10,000 - M 15,000',
      posted: '3 days ago',
      description: 'Seeking an experienced accountant to manage financial records...',
      skills: ['QuickBooks', 'Tax Preparation', 'Financial Reporting', 'Excel'],
      experience: 'Mid-level'
    },
    {
      id: 4,
      title: 'Sales Representative',
      company: 'Retail Solutions',
      location: 'Mafeteng',
      type: 'Full-time',
      category: 'Sales',
      salary: 'M 8,000 - M 12,000',
      posted: '1 week ago',
      description: 'Dynamic sales role with opportunities for growth and commission...',
      skills: ['Sales', 'Customer Service', 'Communication', 'CRM'],
      experience: 'Entry-level'
    },
    {
      id: 5,
      title: 'Project Manager',
      company: 'Construction Plus',
      location: 'Maseru',
      type: 'Contract',
      category: 'Construction',
      salary: 'M 20,000 - M 30,000',
      posted: '5 days ago',
      description: 'Lead construction projects from planning to completion...',
      skills: ['Project Management', 'Construction', 'Leadership', 'Planning'],
      experience: 'Senior'
    },
    {
      id: 6,
      title: 'Nurse',
      company: 'Lesotho Health Services',
      location: 'Mohale\'s Hoek',
      type: 'Full-time',
      category: 'Healthcare',
      salary: 'M 9,000 - M 14,000',
      posted: '4 days ago',
      description: 'Provide quality healthcare services to our community...',
      skills: ['Patient Care', 'Medical Knowledge', 'Communication', 'Emergency Response'],
      experience: 'Mid-level'
    }
  ];

  useEffect(() => {
    // Initialize jobs
    setJobs(mockJobs);
    setFilteredJobs(mockJobs);

    // Check for search query from URL
    const urlParams = new URLSearchParams(location.search);
    const search = urlParams.get('search');
    if (search) {
      setSearchQuery(search);
    }
  }, [location.search]);

  useEffect(() => {
    // Filter jobs based on search and filters
    let filtered = jobs;

    if (searchQuery) {
      filtered = filtered.filter(job =>
        job.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        job.company.toLowerCase().includes(searchQuery.toLowerCase()) ||
        job.skills.some(skill => skill.toLowerCase().includes(searchQuery.toLowerCase()))
      );
    }

    if (filters.location) {
      filtered = filtered.filter(job => job.location === filters.location);
    }

    if (filters.category) {
      filtered = filtered.filter(job => job.category === filters.category);
    }

    if (filters.type) {
      filtered = filtered.filter(job => job.type === filters.type);
    }

    if (filters.experience) {
      filtered = filtered.filter(job => job.experience === filters.experience);
    }

    setFilteredJobs(filtered);
  }, [searchQuery, filters, jobs]);

  const handleFilterChange = (key: string, value: string) => {
    setFilters(prev => ({
      ...prev,
      [key]: value
    }));
  };

  const clearFilters = () => {
    setFilters({
      location: '',
      category: '',
      type: '',
      experience: '',
      salaryRange: ''
    });
    setSearchQuery('');
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">{t('jobs.title')}</h1>
          <p className="text-gray-600">Discover your next career opportunity in Lesotho</p>
        </div>

        {/* Search Bar */}
        <div className="bg-white rounded-lg shadow-md mb-6 p-6">
          <div className="flex flex-col lg:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="h-5 w-5 text-gray-400 absolute left-3 top-3" />
                <input
                  type="text"
                  placeholder="Search jobs, companies, or skills..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
            </div>
            <button
              onClick={() => setShowFilters(!showFilters)}
              className="flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
            >
              <Filter className="h-5 w-5" />
              <span>{t('jobs.filters')}</span>
              <ChevronDown className={`h-4 w-4 transition-transform ${showFilters ? 'rotate-180' : ''}`} />
            </button>
          </div>

          {/* Filters */}
          {showFilters && (
            <div className="mt-6 pt-6 border-t border-gray-200">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    {t('jobs.location')}
                  </label>
                  <select
                    value={filters.location}
                    onChange={(e) => handleFilterChange('location', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="">All Locations</option>
                    <option value="Maseru">Maseru</option>
                    <option value="Hlotse">Hlotse</option>
                    <option value="Mafeteng">Mafeteng</option>
                    <option value="Mohale's Hoek">Mohale's Hoek</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    {t('jobs.category')}
                  </label>
                  <select
                    value={filters.category}
                    onChange={(e) => handleFilterChange('category', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="">All Categories</option>
                    <option value="Technology">Technology</option>
                    <option value="Marketing">Marketing</option>
                    <option value="Finance">Finance</option>
                    <option value="Sales">Sales</option>
                    <option value="Construction">Construction</option>
                    <option value="Healthcare">Healthcare</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    {t('jobs.jobType')}
                  </label>
                  <select
                    value={filters.type}
                    onChange={(e) => handleFilterChange('type', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="">All Types</option>
                    <option value="Full-time">Full-time</option>
                    <option value="Part-time">Part-time</option>
                    <option value="Contract">Contract</option>
                    <option value="Internship">Internship</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    {t('jobs.experience')}
                  </label>
                  <select
                    value={filters.experience}
                    onChange={(e) => handleFilterChange('experience', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="">All Levels</option>
                    <option value="Entry-level">Entry-level</option>
                    <option value="Mid-level">Mid-level</option>
                    <option value="Senior">Senior</option>
                  </select>
                </div>
              </div>

              <div className="mt-4 flex justify-end">
                <button
                  onClick={clearFilters}
                  className="px-4 py-2 text-gray-600 hover:text-gray-800 transition-colors"
                >
                  Clear All Filters
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Results */}
        <div className="flex flex-col lg:flex-row gap-6">
          {/* Job List */}
          <div className="flex-1">
            <div className="mb-4 flex justify-between items-center">
              <p className="text-gray-600">
                {filteredJobs.length} job{filteredJobs.length !== 1 ? 's' : ''} found
              </p>
            </div>

            <div className="space-y-6">
              {filteredJobs.map((job) => (
                <div key={job.id} className="job-card bg-white rounded-lg shadow-md p-6">
                  <div className="flex justify-between items-start mb-4">
                    <div className="flex-1">
                      <h3 className="text-xl font-semibold text-gray-900 mb-2">
                        <Link to={`/jobs/${job.id}`} className="hover:text-blue-600 transition-colors">
                          {job.title}
                        </Link>
                      </h3>
                      <p className="text-gray-600 font-medium mb-2">{job.company}</p>
                      <div className="text-green-600 font-semibold mb-2">{job.salary}</div>
                    </div>
                    <div className="text-right text-sm text-gray-500">
                      <Clock className="h-4 w-4 inline mr-1" />
                      {job.posted}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                    <div className="flex items-center text-gray-600">
                      <MapPin className="h-4 w-4 mr-2" />
                      {job.location}
                    </div>
                    <div className="flex items-center text-gray-600">
                      <Briefcase className="h-4 w-4 mr-2" />
                      {job.type}
                    </div>
                    <div className="flex items-center text-gray-600">
                      <DollarSign className="h-4 w-4 mr-2" />
                      {job.experience}
                    </div>
                  </div>

                  <p className="text-gray-600 mb-4 line-clamp-2">{job.description}</p>

                  <div className="flex flex-wrap gap-2 mb-4">
                    {job.skills.slice(0, 4).map((skill) => (
                      <span 
                        key={skill}
                        className="skill-tag px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm"
                      >
                        {skill}
                      </span>
                    ))}
                    {job.skills.length > 4 && (
                      <span className="px-3 py-1 bg-gray-100 text-gray-600 rounded-full text-sm">
                        +{job.skills.length - 4} more
                      </span>
                    )}
                  </div>

                  <div className="flex justify-between items-center">
                    <span className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm">
                      {job.category}
                    </span>
                    <Link
                      to={`/jobs/${job.id}`}
                      className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
                    >
                      View Details
                    </Link>
                  </div>
                </div>
              ))}
            </div>

            {filteredJobs.length === 0 && (
              <div className="text-center py-12">
                <div className="text-gray-400 mb-4">
                  <Search className="h-16 w-16 mx-auto" />
                </div>
                <h3 className="text-lg font-medium text-gray-900 mb-2">No jobs found</h3>
                <p className="text-gray-600 mb-4">
                  Try adjusting your search criteria or filters
                </p>
                <button
                  onClick={clearFilters}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  Clear All Filters
                </button>
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div className="lg:w-80">
            <div className="bg-white rounded-lg shadow-md p-6 mb-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Job Alerts</h3>
              <p className="text-gray-600 text-sm mb-4">
                Get notified when new jobs matching your criteria are posted.
              </p>
              <button className="w-full px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                Create Job Alert
              </button>
            </div>

            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Popular Categories</h3>
              <div className="space-y-2">
                {['Technology', 'Healthcare', 'Finance', 'Education', 'Construction'].map((category) => (
                  <button
                    key={category}
                    onClick={() => handleFilterChange('category', category)}
                    className="block w-full text-left px-3 py-2 text-gray-600 hover:bg-gray-50 rounded-lg transition-colors"
                  >
                    {category}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Jobs;