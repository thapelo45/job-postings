import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Search, Briefcase, Users, Building, MapPin, Clock, Star } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

const Home: React.FC = () => {
  const { t } = useLanguage();
  const [searchQuery, setSearchQuery] = useState('');
  const navigate = useNavigate();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    navigate(`/jobs?search=${encodeURIComponent(searchQuery)}`);
  };

  const featuredJobs = [
    {
      id: 1,
      title: 'Software Developer',
      company: 'TechCorp Lesotho',
      location: 'Maseru',
      type: 'Full-time',
      salary: 'M 15,000 - M 25,000',
      posted: '2 days ago',
      skills: ['React', 'Node.js', 'TypeScript']
    },
    {
      id: 2,
      title: 'Marketing Manager',
      company: 'Digital Solutions Ltd',
      location: 'Maseru',
      type: 'Full-time',
      salary: 'M 12,000 - M 18,000',
      posted: '1 day ago',
      skills: ['Digital Marketing', 'SEO', 'Analytics']
    },
    {
      id: 3,
      title: 'Accountant',
      company: 'Finance Pro Services',
      location: 'Hlotse',
      type: 'Full-time',
      salary: 'M 10,000 - M 15,000',
      posted: '3 days ago',
      skills: ['QuickBooks', 'Tax', 'Financial Reporting']
    }
  ];

  const topCompanies = [
    { name: 'Lesotho Bank', logo: '🏦', jobs: 12 },
    { name: 'Vodacom Lesotho', logo: '📱', jobs: 8 },
    { name: 'Maluti Holdings', logo: '🏢', jobs: 15 },
    { name: 'Lesotho Flour Mills', logo: '🌾', jobs: 6 }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="lesotho-gradient text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6 fade-in">
            {t('home.title')}
          </h1>
          <p className="text-xl md:text-2xl mb-8 text-blue-100 slide-up">
            {t('home.subtitle')}
          </p>
          
          {/* Search Bar */}
          <form onSubmit={handleSearch} className="max-w-2xl mx-auto mb-12 slide-up">
            <div className="flex bg-white rounded-full shadow-lg overflow-hidden">
              <input
                type="text"
                placeholder={t('home.searchPlaceholder')}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="flex-1 px-6 py-4 text-gray-900 focus:outline-none"
              />
              <button
                type="submit"
                className="bg-blue-600 hover:bg-blue-700 px-8 py-4 text-white font-semibold transition-colors"
              >
                <Search className="h-5 w-5" />
              </button>
            </div>
          </form>

          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div className="text-center">
              <div className="text-4xl font-bold mb-2">2,500+</div>
              <div className="text-blue-100">{t('home.stats.jobs')}</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold mb-2">450+</div>
              <div className="text-blue-100">{t('home.stats.companies')}</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold mb-2">15,000+</div>
              <div className="text-blue-100">{t('home.stats.candidates')}</div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Jobs */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Featured Job Opportunities
            </h2>
            <p className="text-xl text-gray-600">
              Discover the latest job openings from top employers in Lesotho
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
            {featuredJobs.map((job) => (
              <div key={job.id} className="job-card bg-white rounded-lg shadow-md p-6">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">
                      {job.title}
                    </h3>
                    <p className="text-gray-600 font-medium">{job.company}</p>
                  </div>
                  <div className="text-right text-sm text-gray-500">
                    <Clock className="h-4 w-4 inline mr-1" />
                    {job.posted}
                  </div>
                </div>

                <div className="space-y-2 mb-4">
                  <div className="flex items-center text-gray-600">
                    <MapPin className="h-4 w-4 mr-2" />
                    {job.location}
                  </div>
                  <div className="flex items-center text-gray-600">
                    <Briefcase className="h-4 w-4 mr-2" />
                    {job.type}
                  </div>
                  <div className="text-green-600 font-semibold">
                    {job.salary}
                  </div>
                </div>

                <div className="flex flex-wrap gap-2 mb-4">
                  {job.skills.map((skill) => (
                    <span 
                      key={skill}
                      className="skill-tag px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm"
                    >
                      {skill}
                    </span>
                  ))}
                </div>

                <Link
                  to={`/jobs/${job.id}`}
                  className="block w-full text-center bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition-colors font-medium"
                >
                  View Details
                </Link>
              </div>
            ))}
          </div>

          <div className="text-center">
            <Link
              to="/jobs"
              className="inline-flex items-center px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
            >
              View All Jobs
              <Briefcase className="ml-2 h-5 w-5" />
            </Link>
          </div>
        </div>
      </section>

      {/* Top Companies */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Top Companies Hiring
            </h2>
            <p className="text-xl text-gray-600">
              Join leading organizations in Lesotho
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {topCompanies.map((company) => (
              <div 
                key={company.name}
                className="bg-gray-50 rounded-lg p-6 text-center hover:shadow-md transition-shadow cursor-pointer"
              >
                <div className="text-4xl mb-3">{company.logo}</div>
                <h3 className="font-semibold text-gray-900 mb-2">{company.name}</h3>
                <p className="text-gray-600 text-sm">{company.jobs} open positions</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              How It Works
            </h2>
            <p className="text-xl text-gray-600">
              Get started in just three simple steps
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Create Your Profile</h3>
              <p className="text-gray-600">
                Sign up and create a detailed profile showcasing your skills and experience
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Search className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Find Perfect Jobs</h3>
              <p className="text-gray-600">
                Browse and search for jobs that match your skills and career goals
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-orange-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Star className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Get Hired</h3>
              <p className="text-gray-600">
                Apply to jobs and connect with employers to land your dream position
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-blue-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Ready to Start Your Career Journey?
          </h2>
          <p className="text-xl mb-8 text-blue-100">
            Join thousands of professionals finding their dream jobs in Lesotho
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/register"
              className="px-8 py-4 bg-white text-blue-600 rounded-lg hover:bg-gray-100 transition-colors font-semibold"
            >
              Find Jobs
            </Link>
            <Link
              to="/register"
              className="px-8 py-4 border-2 border-white text-white rounded-lg hover:bg-white hover:text-blue-600 transition-colors font-semibold"
            >
              Post Jobs
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;