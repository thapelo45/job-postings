import React, { useState } from 'react';
import { X, Mail, Phone, MessageCircle, Send, User, Building } from 'lucide-react';

interface ContactModalProps {
  isOpen: boolean;
  onClose: () => void;
  contactInfo: {
    name: string;
    email: string;
    phone?: string;
    userType: 'jobseeker' | 'employer';
    jobTitle?: string;
    companyName?: string;
  };
}

const ContactModal: React.FC<ContactModalProps> = ({ isOpen, onClose, contactInfo }) => {
  const [activeTab, setActiveTab] = useState<'email' | 'phone' | 'message'>('email');
  const [emailSubject, setEmailSubject] = useState('');
  const [emailMessage, setEmailMessage] = useState('');
  const [phoneMessage, setPhoneMessage] = useState('');
  const [directMessage, setDirectMessage] = useState('');

  if (!isOpen) return null;

  const handleSendEmail = () => {
    const subject = encodeURIComponent(emailSubject || `Regarding ${contactInfo.jobTitle || 'Job Opportunity'}`);
    const body = encodeURIComponent(emailMessage);
    window.open(`mailto:${contactInfo.email}?subject=${subject}&body=${body}`);
    onClose();
  };

  const handleCallPhone = () => {
    if (contactInfo.phone) {
      window.open(`tel:${contactInfo.phone}`);
    }
    onClose();
  };

  const handleSendSMS = () => {
    if (contactInfo.phone) {
      const message = encodeURIComponent(phoneMessage);
      window.open(`sms:${contactInfo.phone}?body=${message}`);
    }
    onClose();
  };

  const handleSendMessage = () => {
    // In a real app, this would send through the platform's messaging system
    alert('Message sent successfully! The recipient will be notified.');
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-gray-900">Contact {contactInfo.name}</h2>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 transition-colors"
            >
              <X className="h-6 w-6" />
            </button>
          </div>

          {/* Contact Info */}
          <div className="bg-gray-50 rounded-lg p-4 mb-6">
            <div className="flex items-center space-x-3 mb-3">
              <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center">
                {contactInfo.userType === 'employer' ? (
                  <Building className="h-6 w-6 text-white" />
                ) : (
                  <User className="h-6 w-6 text-white" />
                )}
              </div>
              <div>
                <h3 className="font-semibold text-gray-900">{contactInfo.name}</h3>
                <p className="text-gray-600 text-sm">
                  {contactInfo.userType === 'employer' ? contactInfo.companyName : contactInfo.jobTitle}
                </p>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div className="flex items-center space-x-2 text-gray-600">
                <Mail className="h-4 w-4" />
                <span className="text-sm">{contactInfo.email}</span>
              </div>
              {contactInfo.phone && (
                <div className="flex items-center space-x-2 text-gray-600">
                  <Phone className="h-4 w-4" />
                  <span className="text-sm">{contactInfo.phone}</span>
                </div>
              )}
            </div>
          </div>

          {/* Contact Method Tabs */}
          <div className="border-b border-gray-200 mb-6">
            <nav className="-mb-px flex space-x-8">
              <button
                onClick={() => setActiveTab('email')}
                className={`py-2 px-1 border-b-2 font-medium text-sm ${
                  activeTab === 'email'
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                <div className="flex items-center space-x-2">
                  <Mail className="h-4 w-4" />
                  <span>Email</span>
                </div>
              </button>
              {contactInfo.phone && (
                <button
                  onClick={() => setActiveTab('phone')}
                  className={`py-2 px-1 border-b-2 font-medium text-sm ${
                    activeTab === 'phone'
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <div className="flex items-center space-x-2">
                    <Phone className="h-4 w-4" />
                    <span>Phone</span>
                  </div>
                </button>
              )}
              <button
                onClick={() => setActiveTab('message')}
                className={`py-2 px-1 border-b-2 font-medium text-sm ${
                  activeTab === 'message'
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                <div className="flex items-center space-x-2">
                  <MessageCircle className="h-4 w-4" />
                  <span>Message</span>
                </div>
              </button>
            </nav>
          </div>

          {/* Tab Content */}
          <div className="space-y-4">
            {activeTab === 'email' && (
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Subject
                  </label>
                  <input
                    type="text"
                    value={emailSubject}
                    onChange={(e) => setEmailSubject(e.target.value)}
                    placeholder={`Regarding ${contactInfo.jobTitle || 'Job Opportunity'}`}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Message
                  </label>
                  <textarea
                    value={emailMessage}
                    onChange={(e) => setEmailMessage(e.target.value)}
                    rows={6}
                    placeholder="Type your message here..."
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
                <button
                  onClick={handleSendEmail}
                  className="w-full flex items-center justify-center space-x-2 px-4 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  <Mail className="h-4 w-4" />
                  <span>Send Email</span>
                </button>
              </div>
            )}

            {activeTab === 'phone' && contactInfo.phone && (
              <div className="space-y-4">
                <div className="text-center py-4">
                  <Phone className="h-12 w-12 text-blue-600 mx-auto mb-4" />
                  <p className="text-gray-600 mb-4">
                    Contact {contactInfo.name} directly via phone
                  </p>
                  <p className="text-xl font-semibold text-gray-900 mb-6">
                    {contactInfo.phone}
                  </p>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <button
                    onClick={handleCallPhone}
                    className="flex items-center justify-center space-x-2 px-4 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
                  >
                    <Phone className="h-4 w-4" />
                    <span>Call Now</span>
                  </button>
                  <button
                    onClick={() => {
                      setPhoneMessage(`Hi ${contactInfo.name}, I'm interested in discussing ${contactInfo.jobTitle || 'the job opportunity'}. When would be a good time to talk?`);
                    }}
                    className="flex items-center justify-center space-x-2 px-4 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                  >
                    <MessageCircle className="h-4 w-4" />
                    <span>Send SMS</span>
                  </button>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    SMS Message (Optional)
                  </label>
                  <textarea
                    value={phoneMessage}
                    onChange={(e) => setPhoneMessage(e.target.value)}
                    rows={3}
                    placeholder="Type your SMS message here..."
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                  <button
                    onClick={handleSendSMS}
                    className="w-full mt-3 flex items-center justify-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                  >
                    <Send className="h-4 w-4" />
                    <span>Send SMS</span>
                  </button>
                </div>
              </div>
            )}

            {activeTab === 'message' && (
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Platform Message
                  </label>
                  <textarea
                    value={directMessage}
                    onChange={(e) => setDirectMessage(e.target.value)}
                    rows={6}
                    placeholder={`Send a message to ${contactInfo.name} through the platform...`}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <div className="flex items-start space-x-3">
                    <MessageCircle className="h-5 w-5 text-blue-600 mt-0.5" />
                    <div>
                      <h4 className="font-medium text-blue-900">Platform Messaging</h4>
                      <p className="text-sm text-blue-700">
                        Messages sent through the platform are secure and both parties will receive email notifications.
                      </p>
                    </div>
                  </div>
                </div>
                <button
                  onClick={handleSendMessage}
                  disabled={!directMessage.trim()}
                  className="w-full flex items-center justify-center space-x-2 px-4 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <Send className="h-4 w-4" />
                  <span>Send Message</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContactModal;