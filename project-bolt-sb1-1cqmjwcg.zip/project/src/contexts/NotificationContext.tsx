import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { useAuth } from './AuthContext';

export interface Notification {
  id: string;
  type: 'job_match' | 'application_status' | 'profile_view' | 'new_application' | 'interview_scheduled' | 'message';
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
  actionData?: {
    jobId?: string;
    applicationId?: string;
    userId?: string;
    userType?: 'jobseeker' | 'employer';
    userName?: string;
    userEmail?: string;
    userPhone?: string;
    jobTitle?: string;
    companyName?: string;
  };
}

interface NotificationContextType {
  notifications: Notification[];
  unreadCount: number;
  markAsRead: (notificationId: string) => void;
  markAllAsRead: () => void;
  addNotification: (notification: Omit<Notification, 'id' | 'timestamp' | 'read'>) => void;
  removeNotification: (notificationId: string) => void;
}

const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

export const useNotifications = () => {
  const context = useContext(NotificationContext);
  if (!context) {
    throw new Error('useNotifications must be used within a NotificationProvider');
  }
  return context;
};

export const NotificationProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const [notifications, setNotifications] = useState<Notification[]>([]);

  useEffect(() => {
    if (user) {
      // Load notifications based on user role
      const mockNotifications = generateMockNotifications(user.role, user.id);
      setNotifications(mockNotifications);
    }
  }, [user]);

  const generateMockNotifications = (userRole: string, userId: string): Notification[] => {
    if (userRole === 'jobseeker') {
      return [
        {
          id: '1',
          type: 'job_match',
          title: 'New Job Match Found!',
          message: 'A Software Developer position at TechCorp Lesotho matches your profile.',
          timestamp: new Date(Date.now() - 2 * 60 * 1000).toISOString(),
          read: false,
          actionData: {
            jobId: '1',
            userId: 'emp1',
            userType: 'employer',
            userName: 'TechCorp HR Team',
            userEmail: 'hr@techcorp.co.ls',
            userPhone: '+266 2231 5555',
            jobTitle: 'Software Developer',
            companyName: 'TechCorp Lesotho'
          }
        },
        {
          id: '2',
          type: 'application_status',
          title: 'Application Status Updated',
          message: 'Your application for Marketing Manager has been reviewed.',
          timestamp: new Date(Date.now() - 60 * 60 * 1000).toISOString(),
          read: false,
          actionData: {
            applicationId: '2',
            userId: 'emp2',
            userType: 'employer',
            userName: 'Digital Solutions HR',
            userEmail: 'careers@digitalsolutions.co.ls',
            userPhone: '+266 2231 6666',
            jobTitle: 'Marketing Manager',
            companyName: 'Digital Solutions Ltd'
          }
        },
        {
          id: '3',
          type: 'profile_view',
          title: 'Profile Viewed by Employer',
          message: 'Finance Pro Services viewed your profile.',
          timestamp: new Date(Date.now() - 3 * 60 * 60 * 1000).toISOString(),
          read: true,
          actionData: {
            userId: 'emp3',
            userType: 'employer',
            userName: 'Finance Pro HR',
            userEmail: 'hr@financepro.co.ls',
            userPhone: '+266 2231 7777',
            companyName: 'Finance Pro Services'
          }
        },
        {
          id: '4',
          type: 'interview_scheduled',
          title: 'Interview Scheduled',
          message: 'Interview scheduled for Project Manager position on Jan 20, 2025.',
          timestamp: new Date(Date.now() - 6 * 60 * 60 * 1000).toISOString(),
          read: false,
          actionData: {
            applicationId: '4',
            userId: 'emp4',
            userType: 'employer',
            userName: 'Construction Plus HR',
            userEmail: 'interviews@constructionplus.co.ls',
            userPhone: '+266 2231 8888',
            jobTitle: 'Project Manager',
            companyName: 'Construction Plus'
          }
        }
      ];
    } else if (userRole === 'employer') {
      return [
        {
          id: '5',
          type: 'new_application',
          title: 'New Application Received',
          message: 'John Doe applied for Senior Developer position.',
          timestamp: new Date(Date.now() - 30 * 60 * 1000).toISOString(),
          read: false,
          actionData: {
            applicationId: '1',
            userId: 'js1',
            userType: 'jobseeker',
            userName: 'John Doe',
            userEmail: 'john.doe@email.com',
            userPhone: '+266 5555 0001',
            jobTitle: 'Senior Developer'
          }
        },
        {
          id: '6',
          type: 'new_application',
          title: 'New Application Received',
          message: 'Jane Smith applied for Project Manager position.',
          timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
          read: false,
          actionData: {
            applicationId: '2',
            userId: 'js2',
            userType: 'jobseeker',
            userName: 'Jane Smith',
            userEmail: 'jane.smith@email.com',
            userPhone: '+266 5555 0002',
            jobTitle: 'Project Manager'
          }
        },
        {
          id: '7',
          type: 'profile_view',
          title: 'Job Seeker Viewed Job',
          message: 'Mike Johnson viewed your UI Designer job posting.',
          timestamp: new Date(Date.now() - 4 * 60 * 60 * 1000).toISOString(),
          read: true,
          actionData: {
            jobId: '3',
            userId: 'js3',
            userType: 'jobseeker',
            userName: 'Mike Johnson',
            userEmail: 'mike.johnson@email.com',
            userPhone: '+266 5555 0003',
            jobTitle: 'UI Designer'
          }
        }
      ];
    }
    return [];
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  const markAsRead = (notificationId: string) => {
    setNotifications(prev =>
      prev.map(notification =>
        notification.id === notificationId
          ? { ...notification, read: true }
          : notification
      )
    );
  };

  const markAllAsRead = () => {
    setNotifications(prev =>
      prev.map(notification => ({ ...notification, read: true }))
    );
  };

  const addNotification = (notificationData: Omit<Notification, 'id' | 'timestamp' | 'read'>) => {
    const newNotification: Notification = {
      ...notificationData,
      id: Date.now().toString(),
      timestamp: new Date().toISOString(),
      read: false
    };
    setNotifications(prev => [newNotification, ...prev]);
  };

  const removeNotification = (notificationId: string) => {
    setNotifications(prev => prev.filter(n => n.id !== notificationId));
  };

  return (
    <NotificationContext.Provider value={{
      notifications,
      unreadCount,
      markAsRead,
      markAllAsRead,
      addNotification,
      removeNotification
    }}>
      {children}
    </NotificationContext.Provider>
  );
};