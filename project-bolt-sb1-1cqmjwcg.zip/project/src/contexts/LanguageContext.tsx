import React, { createContext, useContext, useState, ReactNode } from 'react';

type Language = 'en' | 'st';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const translations = {
  en: {
    // Navigation
    'nav.home': 'Home',
    'nav.jobs': 'Jobs',
    'nav.dashboard': 'Dashboard',
    'nav.profile': 'Profile',
    'nav.login': 'Login',
    'nav.register': 'Register',
    'nav.logout': 'Logout',
    
    // Common
    'common.search': 'Search',
    'common.apply': 'Apply',
    'common.cancel': 'Cancel',
    'common.save': 'Save',
    'common.edit': 'Edit',
    'common.delete': 'Delete',
    'common.view': 'View',
    'common.loading': 'Loading...',
    'common.submit': 'Submit',
    
    // Home page
    'home.title': 'Find Your Dream Job in Lesotho',
    'home.subtitle': 'Connecting talented professionals with leading employers across the Kingdom of Lesotho',
    'home.searchPlaceholder': 'Search for jobs, companies, or skills...',
    'home.stats.jobs': 'Active Jobs',
    'home.stats.companies': 'Companies',
    'home.stats.candidates': 'Job Seekers',
    
    // Jobs
    'jobs.title': 'Job Opportunities',
    'jobs.filters': 'Filters',
    'jobs.location': 'Location',
    'jobs.category': 'Category',
    'jobs.experience': 'Experience Level',
    'jobs.salaryRange': 'Salary Range',
    'jobs.jobType': 'Job Type',
    'jobs.postedDate': 'Posted Date',
    
    // Dashboard
    'dashboard.welcome': 'Welcome back',
    'dashboard.overview': 'Dashboard Overview',
    'dashboard.applications': 'Applications',
    'dashboard.jobs': 'Posted Jobs',
    'dashboard.profile': 'Profile Completion',
    
    // Auth
    'auth.login': 'Sign In',
    'auth.register': 'Create Account',
    'auth.email': 'Email Address',
    'auth.password': 'Password',
    'auth.confirmPassword': 'Confirm Password',
    'auth.name': 'Full Name',
    'auth.role': 'I am a',
    'auth.jobseeker': 'Job Seeker',
    'auth.employer': 'Employer',
    
    // Profile
    'profile.title': 'My Profile',
    'profile.personalInfo': 'Personal Information',
    'profile.skills': 'Skills',
    'profile.experience': 'Experience',
    'profile.education': 'Education',
    'profile.resume': 'Resume',
  },
  st: {
    // Navigation
    'nav.home': 'Lehae',
    'nav.jobs': 'Mesebetsi',
    'nav.dashboard': 'Boto ea Taolo',
    'nav.profile': 'Profaele',
    'nav.login': 'Kena',
    'nav.register': 'Ingolise',
    'nav.logout': 'Tsoa',
    
    // Common
    'common.search': 'Batla',
    'common.apply': 'Kopa',
    'common.cancel': 'Hlakola',
    'common.save': 'Boloka',
    'common.edit': 'Lokisa',
    'common.delete': 'Hlakola',
    'common.view': 'Sheba',
    'common.loading': 'E hlaha...',
    'common.submit': 'Romela',
    
    // Home page
    'home.title': 'Fumana Mosebetsi oa Toro ea Hau Lesotho',
    'home.subtitle': 'Re kopanya batho ba nang le talenta le ba qalisi ba mesebitsi hoya Musitho oa Lesotho',
    'home.searchPlaceholder': 'Batla mesebetsi, likhamphani, kapa bokhoni...',
    'home.stats.jobs': 'Mesebetsi e Sebetsang',
    'home.stats.companies': 'Likhamphani',
    'home.stats.candidates': 'Batlang Mesebetsi',
    
    // Jobs
    'jobs.title': 'Menyetla ea Mesebetsi',
    'jobs.filters': 'Hlohlame',
    'jobs.location': 'Sebaka',
    'jobs.category': 'Sehlopha',
    'jobs.experience': 'Boemo ba Phihlelo',
    'jobs.salaryRange': 'Tekano ea Moputso',
    'jobs.jobType': 'Mofuta oa Mosebetsi',
    'jobs.postedDate': 'Letsatsi la ho Phatlalatsa',
    
    // Dashboard
    'dashboard.welcome': 'Rea u amohela hape',
    'dashboard.overview': 'Kakaretso ea Boto ea Taolo',
    'dashboard.applications': 'Likopo',
    'dashboard.jobs': 'Mesebetsi e Phatlalatsitsoeng',
    'dashboard.profile': 'Phethahatso ea Profaele',
    
    // Auth
    'auth.login': 'Kena',
    'auth.register': 'Etsa Akhaonto',
    'auth.email': 'Aterese ea Email',
    'auth.password': 'Nomoro ea Sephiri',
    'auth.confirmPassword': 'Netefatsa Nomoro ea Sephiri',
    'auth.name': 'Lebitso le Feletseng',
    'auth.role': 'Ke',
    'auth.jobseeker': 'Motla Mosebetsi',
    'auth.employer': 'Moqalisi',
    
    // Profile
    'profile.title': 'Profaele ea Ka',
    'profile.personalInfo': 'Litaba tsa Motho',
    'profile.skills': 'Bokhoni',
    'profile.experience': 'Phihlelo',
    'profile.education': 'Thuto',
    'profile.resume': 'CV',
  }
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};

export const LanguageProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>('en');

  const t = (key: string): string => {
    return translations[language][key as keyof typeof translations['en']] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};